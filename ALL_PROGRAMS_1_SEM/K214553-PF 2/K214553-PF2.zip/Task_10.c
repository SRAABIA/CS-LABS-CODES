#include<stdio.h>
int main(){
	int num,a,b,c,d,e,f,g,h,i,j,k,l,x,y;
	printf("\n\tEnter four digit intger: ");
	scanf("%d",&num); 
	if(num>999&&num<=9999)
	{
	a=num%10;
    num/=10;
    b=num%10;
	num/=10;
	c=num%10;
	num/=10;
	d=num%10;
	//printf("\t%d %d %d %d",a,b,c,d);
	e=(d+5)%8;
	f=(c+5)%8;
	g=(b+5)%8;
	h=(a+5)%8;
	//swapping 1 and 2
	x=e;
	e=f;
	f=x;
	//3 and 4	
	y=g;
	g=h;
	h=y;
	printf("\n\tThe encrypted intger is: %d%d%d%d\n",e,f,g,h);
	//to decrypted integer
	x=f;
	f=e;
	e=x;
	//swapping...
	y=h;
	h=g;
	g=y;
	//dividend=(divisor*quotient)+remainder and then subtracting 5
	i=(8*1+e)-5;
	j=(8*1+f)-5;
	k=(8*1+g)-5;
	l=(8*1+h)-5;
	printf("\n\tThe decrypted value is: %d%d%d%d\n",i,j,k,l);
 	
 	if(i==d&&j==c&&k==b&&l==a)
 	{printf("\n\tThe encryption was successful!!\n");
	 }
	else
	printf("\n\tOops! Encryption did not complete successfully.\n");
 }
 else
 printf("\n\tInvalid Input!\n");
		
}
