#include <stdio.h>
#include <string.h>
int main()
{
    int n, i, j, k;
    printf("Enter the no.of days for which report is required (e.g: 30): ");
    scanf("%d", &n);
    int arr[4][n + 1][7], epid[4], s1 = 0, s2 = 0,s3=0,s4=0,s5=0,s6=0,s7=0,s8=0;
    int sum1[5][1] = {0}, sum2[5][1] = {0}, sum3[5][1] = {0}, sum4[5][1] = {0}, sum5[5][1] = {0}, sum6[5][1] = {0}, sum7[5][1] = {0}, sum8[5][1] = {0}; //ep id is a separate array for employee ids since it wont be of any use in further calculations.
    printf("enter the values in the array: \n");
    for (i = 0; i < 4; i++) //represents block //represents EMPLOYEE //MY FIRST EMPLOYEE IS i=0
    {
        printf("************************************\nFOR EMPLOYEE %d\n  Enter employee ID: ", i + 1);
        scanf("%d", &epid[i]);
         for (j = 0; j <= n + 1; j++) //represents rows
         {
            if (j == 0)
            {
                for (k = 1; k < 7; k++) //represents columns    //EACH PRODUCT'S ID
                                        // if(k==0 && k<6)
                                        //array [0][6] ki location should always be empty
                                        //Column 0 should always be zero
                                        //means array[j][0]={0} so that values don't get messed up while adding

                {
                    printf("\nENTER PRODUCT ID %d the value at arr[%d][%d][%d]: ", k, i + 1, j, k);
                    scanf("%d", &arr[i][j][k]);
                }
                
            }
            else if (j >= 1 || j <= n)
            {                           //represents rows
                for (k = 1; k < 7; k++) //represents columns
                                        //EACH PRODUCT PRICES
                {
                    printf("\nDAY %d: ENTER PRODUCT %d SOLD the value at arr[%d][%d][%d]: ",j, k, i + 1, j, k);
                    scanf("%d", &arr[i][j][k]);
                }
            }
        }
        //for ep1
        //FOR FINDING SUM ROW-WISE
        for (j = 1; j <= n + 1; j++)
        {
            s1 = 0;
            for (k = 1; k < 7; k++)
            {
                s1 += arr[1][j][k];
                sum1[j][7] = s1;
            }
        }
        //FOR FINDING SUM COLUMN-WISE
        for (k = 1; k < 7; k++)
        {
            s2 = 0;
            for (j = 1; j <= n + 1; j++)
            {
                s2 += arr[1][j][k];
                sum2[n + 2][k] = s2;
            }
        }
        //for ep2
        //FOR FINDING SUM ROW-WISE
        for (j = 1; j <= n + 1; j++)
        {
            s1 = 0;
            for (k = 1; k < 7; k++)
            {
                s1 += arr[2][j][k];
                sum3[j][7] = s1;
            }
        }
        //FOR FINDING SUM COLUMN-WISE
        for (k = 1; k < 7; k++)
        {
            s2 = 0;
            for (j = 1; j <= n + 1; j++)
            {
                s2 += arr[2][j][k];
                sum4[n + 2][k] = s2;
            }
        }
        //for ep3
        //FOR FINDING SUM ROW-WISE
        for (j = 1; j <= n + 1; j++)
        {
            s1 = 0;
            for (k = 1; k < 7; k++)
            {
                s1 += arr[3][j][k];
                sum5[j][7] = s1;
            }
        }
        //FOR FINDING SUM COLUMN-WISE
        for (k = 1; k < 7; k++)
        {
            s2 = 0;
            for (j = 1; j <= n + 1; j++)
            {
                s2 += arr[3][j][k];
                sum6[n + 2][k] = s2;
            }
        }
        //for ep4
        //FOR FINDING SUM ROW-WISE
        for (j = 1; j <= n + 1; j++)
        {
            s1 = 0;
            for (k = 1; k < 7; k++)
            {
                s1 += arr[4][j][k];
                sum7[j][7] = s1;
            }
        }
        //FOR FINDING SUM COLUMN-WISE
        for (k = 1; k < 7; k++)
        {
            s2 = 0;
            for (j = 1; j <= n + 1; j++)
            {
                s2 += arr[4][j][k];
                sum8[n + 2][k] = s2;
            }
        }

        //now finally printing the grand table we all waited for
        //since it is question requirement to table for PARTICULAR EMPLOYEE
        printf("\nEmployee 1 : ID-%d", epid[0]);
        printf("\n\nSales person\t\tProducts\t\tTotal sales of a person");

        printf("\n  %d %d %d %d %d %d \n", arr[0][0][1], arr[0][0][2], arr[0][0][3], arr[0][0][4], arr[0][0][5]);
        for (j = 1; j < n + 1; j++)
        {

            printf("%d %d %d %d %d %d %d %d\n", j, arr[0][j][1], arr[0][j][2], arr[0][j][3], arr[0][j][4], arr[0][j][5], arr[0][j][6], sum1[j][7]);
        }
        //for sums
        printf("t_p %d %d %d %d %d \n", sum2[n + 2][1], sum2[n + 2][2], sum2[n + 2][3], sum2[n + 2][4], sum2[n + 2][5]);
        //2
        printf("\n\n\n\n");
        printf("\nEmployee 2 : ID-%d", epid[1]);
        printf("\n\nSales person\t\tProducts\t\tTotal sales of a person");

        printf("\n  %d %d %d %d %d %d \n", arr[1][0][1], arr[1][0][2], arr[1][0][3], arr[1][0][4], arr[1][0][5]);
        for (j = 1; j < n + 1; j++)
        {

            printf("%d %d %d %d %d %d %d %d\n", j, arr[1][j][1], arr[1][j][2], arr[1][j][3], arr[1][j][4], arr[1][j][5], arr[1][j][6], sum3[j][7]);
        }
        printf("t_p %d %d %d %d %d \n", sum4[n + 2][1], sum4[n + 2][2], sum4[n + 2][3], sum4[n + 2][4], sum4[n + 2][5]);

        //3
        printf("\n\n\n\n");
        printf("\nEmployee 3 : ID-%d", epid[2]);
        printf("\n\nSales person\t\tProducts\t\tTotal sales of a person");

        printf("\n  %d %d %d %d %d %d \n", arr[2][0][1], arr[2][0][2], arr[2][0][3], arr[2][0][4], arr[2][0][5]);
        for (j = 1; j < n + 1; j++)
        {

            printf("%d %d %d %d %d %d %d %d\n", j, arr[2][j][1], arr[2][j][2], arr[2][j][3], arr[2][j][4], arr[2][j][5], arr[2][j][6], sum5[j][7]);
        }
        printf("t_p %d %d %d %d %d \n", sum6[n + 2][1], sum6[n + 2][2], sum6[n + 2][3], sum6[n + 2][4], sum6[n + 2][5]);

        //4
        printf("\n\n\n\n");
        printf("\nEmployee 4 : ID-%d", epid[3]);
        printf("\n\nSales person\t\tProducts\t\tTotal sales of a person");

        printf("\n  %d %d %d %d %d %d \n", arr[3][0][1], arr[3][0][2], arr[3][0][3], arr[3][0][4], arr[3][0][5]);
        for (j = 1; j < n + 1; j++)
        {

            printf("%d %d %d %d %d %d %d %d\n", j, arr[3][j][1], arr[3][j][2], arr[3][j][3], arr[3][j][4], arr[3][j][5], arr[3][j][6], sum7[j][7]);
        }
        printf("t_p %d %d %d %d %d \n", sum8[n + 2][1], sum8[n + 2][2], sum8[n + 2][3], sum8[n + 2][4], sum8[n + 2][5]);

        printf("*******THE END*******");
        return 0;
    }
}